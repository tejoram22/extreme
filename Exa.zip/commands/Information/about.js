const { MessageEmbed, MessageButton, MessageActionRow } = require("discord.js");

module.exports = {
    name: "about",
    category: "Information",
    aliases: [ "botinfo" ],
    description: "See description about this project",
    args: false,
    usage: "",
    permission: [],
    owner: false,
    execute: async (message, args, client, prefix) => {
     
    const row = new MessageActionRow()
			.addComponents(
        new MessageButton()
    .setLabel("Invite")
    .setStyle("LINK")
    .setURL(`https://discord.com/api/oauth2/authorize?client_id=884784344630198274&permissions=8&scope=bot`),
    new MessageButton()
    .setLabel("Vote Here")
    .setStyle("LINK")
    .setURL("https://top.gg/bot/899500529707782156"),
    new MessageButton()
    .setLabel("Support")
    .setStyle("LINK")
    .setURL("https://discord.gg/EVXM39em2q")
			);

      const mainPage = new MessageEmbed()
            .setAuthor('Exa' , 'https://media.discordapp.net/attachments/902774195329572876/915648031477600286/IMG-20211201-WA0011.jpg')
            .setThumbnail('https://media.discordapp.net/attachments/902774195329572876/915648031477600286/IMG-20211201-WA0011.jpg')
            .setColor('#303236')
            .addField('Creator', ' [-S P I D E Y , - S H R A V A N , GwD Mokshith Dino](https://discord.com/users/758960974409236491)', true)
            .addField('Organization', 'Exa Team', true)
      
            
        return message.channel.send({embeds: [mainPage], components: [row]});
    }
}