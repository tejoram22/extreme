const { MessageEmbed, CommandInteraction, Client, MessageButton, MessageActionRow } = require("discord.js")

module.exports = {
    name: "about",
    description: "Show Pros Music project information",

    /**
     * 
     * @param {Client} client 
     * @param {CommandInteraction} interaction 
     */

    run: async (client, interaction) => {
        await interaction.deferReply({
            ephemeral: false
        });
   const row = new MessageActionRow()
			.addComponents(
        new MessageButton()
    .setLabel("Invite")
    .setStyle("LINK")
    .setURL(`https://discord.com/api/oauth2/authorize?client_id=899500529707782156&permissions=534790011712&scope=bot%20applications.commands`),
			new MessageButton()
    .setLabel("vote Here")
    .setStyle("LINK")
    .setURL("https://top.gg/bot/899500529707782156"),
    new MessageButton()
    .setLabel("Support")
    .setStyle("LINK")
    .setURL("https://discord.gg/tYTxrjugVn")
			);

      const mainPage = new MessageEmbed()
            .setAuthor('LightMusic', 'https://media.discordapp.net/attachments/908741825546842173/908755528077942814/images.png?width=579&height=486')
            .setThumbnail('https://media.discordapp.net/attachments/908741825546842173/908755528077942814/images.png?width=579&height=486')
            .setColor('#303236')
            .addField('Main Dev', '[R A H U L #7608](https://discord.com/users/758960974409236491)' 
, true) 
            .addField('Organization', 'LIGHT MUSIC TEAM', true)
 
 
        await interaction.followUp({embeds: [mainPage], components: [row]});
    }
}
