const { MessageEmbed, MessageActionRow, MessageButton } = require("discord.js");

module.exports = {
    name: "invite",
    category: "Information",
    aliases: [ "invi", "inv" ],
    description: "invite Exa",
    args: false,
    usage: "",
    permission: [],
    owner: false,
   execute: async (message, args, client, prefix) => {
         
         
    const row = new MessageActionRow()
			.addComponents(
        new MessageButton()
    .setLabel("Invite")
    .setStyle("LINK")
    .setURL(`https://discord.com/api/oauth2/authorize?client_id=884784344630198274&permissions=8&scope=bot`),
			new MessageButton()
    .setLabel("Vote Here")
    .setStyle("LINK")
    .setURL("https://top.gg/bot/899500529707782156"),
    new MessageButton()
    .setLabel("Support")
    .setStyle("LINK")
    .setURL("https://discord.gg/EVXM39em2q")
			);

          const mainPage = new MessageEmbed()
            .setAuthor('Exa' , 'https://media.discordapp.net/attachments/902774195329572876/915648031477600286/IMG-20211201-WA0011.jpg')
            .setThumbnail('https://media.discordapp.net/attachments/902774195329572876/915648031477600286/IMG-20211201-WA0011.jpg')
             .setColor('#303236')
            .addField('invite Exa', `[Here](https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=36768832&scope=applications.commands%20bot)`,true)
             .addField("Features","__Exa__ is one of the best high quality music bots out there. We provide all premium features like 24/7 modes and much more at absolutely no cost! ",true)
           message.channel.send({embeds: [mainPage], components: [row]})
    }
}